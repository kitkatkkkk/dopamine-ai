-- =====================================================================
-- SENIM AI | 002_senim_seed_demo.sql
-- ТОЛЬКО ВЫМЫШЛЕННЫЕ ДАННЫЕ. Запускать после 001_senim_schema.sql.
-- Можно запускать повторно: старые демо-данные удаляются и создаются заново.
-- Демо-пользователи не имеют пароля и не предназначены для входа.
-- =====================================================================

begin;

-- Повторный запуск: убираем прежние демо-данные (каскадом удаляются профили, настроение, слоты)
delete from auth.users where email like '%@seed.senim.invalid';

-- Список вымышленных людей: 24 участника на каждое учреждение + 1 психолог
create temp table seed_people on commit drop as
select md5('senim-seed:' || i.id || ':' || n)::uuid as id,
       i.id   as institution_id,
       i.kind as kind,
       'participant'::text as person,
       n
from public.institutions i
cross join generate_series(1, 24) as n
union all
select md5('senim-seed-psy:' || i.id)::uuid, i.id, i.kind, 'psychologist'::text, 0
from public.institutions i;

-- Учётные записи (профиль создаст триггер handle_new_user)
insert into auth.users (instance_id, id, aud, role, email, raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
select '00000000-0000-0000-0000-000000000000'::uuid,
       s.id,
       'authenticated',
       'authenticated',
       'demo-' || s.person || '-' || s.institution_id || '-' || lpad(s.n::text, 2, '0') || '@seed.senim.invalid',
       '{"provider":"email","providers":["email"]}'::jsonb,
       '{"seed":true}'::jsonb,
       now(),
       now()
from seed_people s;

-- Роли и учреждения выставляет сервер (этот скрипт), а не пользователь
update public.profiles p
   set institution_id    = s.institution_id,
       role              = case
                             when s.person = 'psychologist' then 'psychologist'::public.app_role
                             when s.kind = 'school'         then 'pupil'::public.app_role
                             else 'student'::public.app_role
                           end,
       display_name      = case
                             when s.person = 'psychologist' then 'Demo psychologist (' || s.institution_id || ')'
                             else 'Demo participant ' || lpad(s.n::text, 2, '0')
                           end,
       membership_locked = true
  from seed_people s
 where p.id = s.id;

-- Настроение за последние 28 дней: каждый участник через день.
-- Значения псевдослучайные, но повторяемые (одинаковые при каждом запуске).
insert into public.mood_entries (user_id, entry_date, mood, factors)
select s.id,
       current_date - d,
       (1 + ((hashtext(s.id::text || ':m:' || d) & 2147483647) % 5))::smallint,
       array[(array['study', 'sleep', 'social', 'family', 'health'])
             [1 + ((hashtext(s.id::text || ':f:' || d) & 2147483647) % 5)]]
from seed_people s
cross join generate_series(0, 27) as d
where s.person = 'participant'
  and (d + s.n) % 2 = 0;

-- Слоты психологов: ближайшие 3 дня, 3 слота в день (04:00 / 06:00 / 09:00 UTC = 09:00 / 11:00 / 14:00 в Кызылорде)
insert into public.psychologist_slots (psychologist_id, institution_id, starts_at, ends_at)
select s.id,
       s.institution_id,
       date_trunc('day', now()) + make_interval(days => d, hours => h),
       date_trunc('day', now()) + make_interval(days => d, hours => h + 1)
from seed_people s
cross join generate_series(1, 3) as d
cross join (values (4), (6), (9)) as hh(h)
where s.person = 'psychologist';

commit;
