-- =====================================================================
-- SENIM AI | 001_rollback.sql
-- Полностью убирает всё, что создали 001_senim_schema.sql и 002_senim_seed_demo.sql.
-- Запускать ТОЛЬКО в демо-проекте. Данные удаляются безвозвратно.
-- =====================================================================

begin;

-- 1. Демо-пользователи (каскадом удаляются их профили, настроение, слоты, записи)
delete from auth.users where email like '%@seed.senim.invalid';

-- 2. Триггер на auth.users
drop trigger if exists on_auth_user_created on auth.users;

-- 3. Функции (по именам, чтобы не перечислять сигнатуры)
do $$
declare
  r record;
begin
  for r in
    select p.oid::regprocedure as sig
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.proname = any (array[
        'touch_updated_at', 'handle_new_user', 'slot_integrity',
        'my_role', 'my_institution', '_revoke_sharing',
        'complete_onboarding', 'admin_set_staff_role',
        'list_available_slots', 'request_appointment', 'cancel_appointment',
        'set_appointment_status', 'list_assigned_appointments',
        'share_mood_entries', 'revoke_mood_sharing', 'get_shared_mood_entries',
        'get_institution_summary'
      ])
  loop
    execute 'drop function ' || r.sig || ' cascade';
  end loop;
end $$;

-- 4. Таблицы (с учётом циклической связи consents <-> appointments)
drop table if exists
  public.mood_shares,
  public.appointments,
  public.consents,
  public.psychologist_slots,
  public.mood_entries,
  public.profiles,
  public.institutions
cascade;

-- 5. Типы
drop type if exists public.consent_kind;
drop type if exists public.appointment_status;
drop type if exists public.app_role;
drop type if exists public.institution_kind;

commit;
